import fs from 'node:fs/promises';
import path from 'node:path';
import {execFileSync} from 'node:child_process';
const own=path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Za-z]:)/,'$1'));
const progress=path.join(own,'2026-11-10T00-10-15-130Z/progress.json');
for(;;){
 const j=JSON.parse(await fs.readFile(progress,'utf8'));
 const row=j.results.find(r=>r.script==='frontend/tools/check-warehouse-worker-walk-v3.mjs');
 if(row){
  const command=`$p=Get-CimInstance Win32_Process -Filter 'ProcessId=30616'; if(!$p){throw 'Expected owned prefix runner absent'}; if($p.CommandLine -cne '"C:\\Program Files\\nodejs\\node.exe" frontend/tools/run-current-regression-v3.mjs' -or $p.CreationDate.ToUniversalTime().ToString('s') -ne '2026-11-10T00:10:15'){throw 'Owned prefix runner identity changed'}; $children=@(Get-CimInstance Win32_Process -Filter 'ParentProcessId=30616'); if($children | Where-Object {$_.CommandLine -like '*check-warehouse-worker-walk-v3.mjs*'}){throw 'Worker-walk must finish before orchestration stop'}; $duplicates=@($children | Where-Object {$_.Name -eq 'node.exe' -and $_.CommandLine.Contains('C:\\Users\\izbas\\Documents\\Codex\\_qt-desktop-deep-1110-c1\\frontend\\tools\\check-')}); Stop-Process -Id 30616; foreach($c in $duplicates){Stop-Process -Id $c.ProcessId -ErrorAction SilentlyContinue}; [pscustomobject]@{stopped_parent=30616;stopped_duplicate_children=@($duplicates.ProcessId);worker_walk_not_interrupted=$true} | ConvertTo-Json -Compress`;
  let output,error;try{output=execFileSync('pwsh',['-NoProfile','-NonInteractive','-Command',command],{encoding:'utf8',timeout:15000,windowsHide:true});}catch(e){error=String(e);}
  const result={walk_row:row,unique_prefix_checks:11,tail_checks_expected:32,output,error,scope:'Stop only verified prefix orchestration after completed worker-walk; preserve raw failures. Remaining32 are separately executing.'};
  await fs.writeFile(path.join(own,'prefix-stop.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));if(error)process.exitCode=1;break;
 }
 await new Promise(r=>setTimeout(r,1000));
}
