import fs from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import assert from 'node:assert/strict';
const base=path.dirname(fileURLToPath(import.meta.url)),repo=path.resolve(base,'../../../..');
const hash=b=>createHash('sha256').update(b).digest('hex');
const read=p=>fs.readFile(path.join(repo,p));
const names=s=>[...s.match(/const names=\[([\s\S]*?)\];/)[1].matchAll(/'([^']+\.mjs)'/g)].map(m=>'frontend/tools/'+m[1]);
const original=names(await fs.readFile(path.join(base,'initial-43-runner.mjs'),'utf8'));
assert.equal(original.length,43);
const archivedScript='frontend/tools/check-warehouse-palm-support-v3.mjs';
const eligible=original.filter(n=>n!==archivedScript);
assert.deepEqual(names((await read('frontend/tools/run-current-regression-v3.mjs')).toString()),eligible);
const attempts=[],reports=[];
for(const entry of (await fs.readdir(base,{withFileTypes:true})).filter(e=>e.isDirectory()&&/^2026-/.test(e.name)).sort((a,b)=>a.name.localeCompare(b.name))){
 let p=path.join(base,entry.name,'checks.json'),j;
 try{j=JSON.parse(await fs.readFile(p,'utf8'));}catch{p=path.join(base,entry.name,'progress.json');try{j=JSON.parse(await fs.readFile(p,'utf8'));}catch{continue;}}
 if(!Array.isArray(j.results))continue;
 reports.push({path:path.relative(repo,p).replaceAll('\\','/'),sha256:hash(await fs.readFile(p))});
 for(const r of j.results){
  const duplicate=entry.name==='2026-11-10T00-10-15-130Z'&&!original.slice(0,11).includes(r.script);
  attempts.push({...r,run:entry.name,report:reports.at(-1).path,excluded_interrupted_duplicate:duplicate});
 }
}
const selected=new Map();for(const r of attempts)if(eligible.includes(r.script)&&!r.excluded_interrupted_duplicate)selected.set(r.script,r);
const costsPath='work/v3/full-tz-closeout-20261109/scenario-costs-source-long/checks.json',costs=JSON.parse(await read(costsPath));
assert.equal(costs.passed,true);assert.equal(costs.checks.length,7);
const costScript='frontend/tools/check-warehouse-scenario-source-costs-v3.mjs';
selected.set(costScript,{script:costScript,script_sha256:costs.source_hashes[costScript],passed:true,observed_exit_code:0,observation:'Parent observed the affected CLI PASS7; this aggregate verifies the report and exact current checker SHA.',proof:costsPath,proof_sha256:hash(await read(costsPath)),groups:7});
const extrasPath='work/v3/full-tz-closeout-20261109/extra-production-regressions.json',extras=JSON.parse(await read(extrasPath));assert.equal(extras.passed,true);assert.equal(extras.modules,3);
for(const r of extras.results){assert(!selected.has(r.script));if(r.proof)assert.equal(hash(await read(r.proof)),r.proof_sha256);selected.set(r.script,{...r,origin:extrasPath});}
const expected=[...eligible,...extras.results.map(r=>r.script)];assert.equal(new Set(expected).size,45);
const results=[];for(const script of expected){const r=selected.get(script),current=hash(await read(script));results.push({...r,script,current_script_sha256:current,source_matches:r?.script_sha256===current,passed:!!r?.passed&&r.script_sha256===current});}
const archivedAttempts=attempts.filter(r=>r.script===archivedScript);
assert.equal(hash(await read(archivedScript)),'e3102fe8970fd22789cdabb04d5de376a51f24d55c6e978f697c9114432c3d19');
const repairPaths=['frontend/tools/check-warehouse-cargo-geometry-v3.mjs','frontend/tools/check-warehouse-layout-plan-v3.mjs','frontend/tools/check-warehouse-original-character-v3.mjs','frontend/tools/check-warehouse-pallet-transfer-scene-v3.mjs','frontend/tools/check-warehouse-staffing-pending-work-v3.mjs','frontend/tools/check-warehouse-staffing-scene-v3.mjs','frontend/tools/check-worker-role-assignment-v3.mjs','frontend/tools/check-twin-inventory-v3.mjs','frontend/tools/run-current-regression-v3.mjs','frontend/tools/native-convex-joint-v3.mjs','frontend/tools/fixtures/staffing-legacy-8156-before.json'];
const repairHashes=Object.fromEntries(await Promise.all(repairPaths.map(async p=>[p,hash(await read(p))])));
const output={schema_id:'qoima.current-production-regression-aggregate.v1',source_kind:'visual_fixture',engine_operation:false,passed:results.every(r=>r.passed),eligible_modules:45,base_eligible_modules:42,supplemental_modules:3,passed_count:results.filter(r=>r.passed).length,failed_count:results.filter(r=>!r.passed).length,initial_planned_inventory:43,archived_checks:[{script:archivedScript,checker_sha256:'e3102fe8970fd22789cdabb04d5de376a51f24d55c6e978f697c9114432c3d19',classification:'ARCHIVED_MODIFIED_BODY_EXPERIMENT',production_pass:false,required_ignored_pose_path:'work/v3/close-hold/accepted-pose.json',required_nondefault_model_path:'frontend/public/models/v3/worker-base-close-hold.glb',reason:'User selected exact original542 character. This obsolete modified-body both-pad experiment is excluded explicitly, not fabricated or silently passed.',raw_attempts:archivedAttempts}],results,raw_reports:reports,raw_failures:attempts.filter(r=>!r.passed),orchestration:JSON.parse(await fs.readFile(path.join(base,'prefix-stop.json'),'utf8')),harness_and_dependency_hashes:repairHashes,root_supplemental_ref:{path:extrasPath,sha256:hash(await read(extrasPath))},root_cost_ref:{path:costsPath,sha256:hash(await read(costsPath))},limitations:['Distinct production modules are counted once across preserved initial, split-tail and affected-only executions. Raw43 was not all PASS.','The full22-route worker-walk finished before its parent orchestration and just-started duplicate successor were stopped.','Checker portability fixes preserve all native tolerances, physical assertions and original frozen golden hashes. Runtime modules/GLBs were not changed.','Native-pair20 is observed CLI fixture coverage, not an actual HTTP/backend pair run. Official33 and hardware browser checks are separate reports.']};
await fs.writeFile(path.join(base,'aggregate-45-checks.json'),JSON.stringify(output,null,2)+'\n');
console.log(JSON.stringify({passed:output.passed,eligible:45,passed_count:output.passed_count,failed:results.filter(r=>!r.passed).map(r=>r.script),out:path.join(base,'aggregate-45-checks.json')}));
if(!output.passed)process.exitCode=1;
