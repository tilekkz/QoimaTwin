"""Execute unmodified historical check-only scripts with bounded read-only Git-blob data IO."""
import sys,os,json,hashlib,subprocess,pathlib,runpy,contextlib,time,datetime,traceback
repo=pathlib.Path(__file__).resolve().parents[2];revision='a54beadcae4c0d5561a943c24b80e7968099996f';out=pathlib.Path(__file__).resolve().parent
assert subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD']).decode().strip()==revision
current=pathlib.Path('C:/Users/izbas/Documents/Codex/2026-11-06/new-chat/work/QoimaTwin');suite=json.loads((current/'tools/visual/v3/deep_validation_suite.json').read_text());ids=['q03','w10-inputs','w10-inputs-independent','w12-historical-input','w12-historical-input-independent'];selected=[next(r for r in suite['commands'] if r['id']==i) for i in ids]
oldbytes=pathlib.Path.read_bytes;oldtext=pathlib.Path.read_text;cache={};observed={};total=0
tracked=set(subprocess.check_output(['git','-C',str(repo),'ls-tree','-r','--name-only',revision]).decode().splitlines())
def provider(p):
 global total
 try:r=str(p.resolve().relative_to(repo)).replace('\\','/')
 except ValueError:return oldbytes(p)
 if r not in tracked:return oldbytes(p)
 if r not in cache:
  b=subprocess.check_output(['git','-C',str(repo),'show',revision+':'+r],timeout=30);total+=len(b);assert total<100*1024*1024,'Bounded virtual historical input bytes exceeded100MB';cache[r]=b;observed[r]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
 return cache[r]
def read_text(p,encoding=None,errors=None):return provider(p).decode(encoding or 'utf-8',errors or 'strict')
results=[]
for row in selected:
 script=repo/row['script'];original=oldbytes(script);assert hashlib.sha256(original).hexdigest()==hashlib.sha256((current/row['script']).read_bytes()).hexdigest()
 stdout=out/(row['id']+'.stdout.txt');stderr=out/(row['id']+'.stderr.txt');assert not stdout.exists() and not stderr.exists();started=time.monotonic();result={'id':row['id'],'script':row['script'],'args':row['args'],'historical_script_sha256':hashlib.sha256(original).hexdigest(),'script_byte_identical_to_current':True}
 with stdout.open('x',encoding='utf-8') as so,stderr.open('x',encoding='utf-8') as se,contextlib.redirect_stdout(so),contextlib.redirect_stderr(se):
  pathlib.Path.read_bytes=provider;pathlib.Path.read_text=read_text;sys.argv=[str(script),*row['args']]
  try:runpy.run_path(str(script),run_name='__main__');result.update(passed=True,exit_code=0)
  except SystemExit as e:result.update(passed=e.code in [0,None],exit_code=e.code)
  except BaseException as e:traceback.print_exc();result.update(passed=False,exit_code=1,error=type(e).__name__+': '+str(e))
  finally:pathlib.Path.read_bytes=oldbytes;pathlib.Path.read_text=oldtext
 result['elapsed_s']=round(time.monotonic()-started,3);result['stdout']={'file':stdout.name,'sha256':hashlib.sha256(oldbytes(stdout)).hexdigest()};result['stderr']={'file':stderr.name,'sha256':hashlib.sha256(oldbytes(stderr)).hexdigest()};results.append(result);print(json.dumps(result),flush=True)
proof={'schema_id':'qoima.historical-validators-source-epoch.v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'passed':all(r['passed'] for r in results),'source_kind':'historical_frozen_visual_fixture','operational_admission':False,'git_revision':revision,'sparse_source_worktree':str(repo),'source_data_provider':'pathlib.read_bytes/read_text transparently read exact tracked Git blobs at the declared revision, including native image/model SHA inputs; no code assertions, expected hashes, old receipts or current sources changed. No new visual inspection claimed.','materialized_heavy_assets':False,'original_current_raw28_result':'23PASS/5FAIL remains preserved separately','virtual_git_input_bytes':total,'input_blob_hashes':observed,'fixture_sha256':observed.get('frontend/public/data/v3/warehouse-fixture-v3.json'),'route_policy_sha256':observed.get('frontend/public/data/v3/route-policy-v3.json'),'results':results};(out/'checks.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps({'passed':proof['passed'],'commands':len(results),'failed':sum(not r['passed'] for r in results),'read_git_bytes':total,'out':str(out)}));sys.exit(0 if proof['passed'] else 1)
